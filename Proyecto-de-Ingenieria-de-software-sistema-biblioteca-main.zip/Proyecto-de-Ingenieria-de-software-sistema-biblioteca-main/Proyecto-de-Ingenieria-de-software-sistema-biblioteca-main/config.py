import os

class Config:
    # Configuración general
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'tu-clave-secreta-aqui-cambiala'
    
    # Configuración de la base de datos MSSQL
    SQLALCHEMY_DATABASE_URI = (
        'mssql+pyodbc://localhost:1433/libreria?'
        'driver=ODBC+Driver+17+for+SQL+Server&'
        'trusted_connection=yes'
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False


import pyodbc

# Parámetros de conexión
server = r'MARDIN-ACEVEDO\SQLEXPRESS'  # usa r'' para evitar problemas con \
database = 'Biblioteca_2-mejorada'
username = 'sa'
password = 'mardin123'

# Cadena de conexión
connection_string = f"""
DRIVER={{ODBC Driver 17 for SQL Server}};
SERVER={server};
DATABASE={database};
UID={username};
PWD={password};
"""

try:
    # Conectarse a SQL Server . 
    conn = pyodbc.connect(connection_string)
    cursor = conn.cursor()
    print(" Conexión exitosa a SQL Server")

    # Ejemplo de consulta
    cursor.execute("SELECT TOP 5 * FROM Autores") 
    for row in cursor.fetchall():
        print(row)

except Exception as e:
    print(" Error al conectar a SQL Server:", e)

finally:
    if 'conn' in locals():
        conn.close()
