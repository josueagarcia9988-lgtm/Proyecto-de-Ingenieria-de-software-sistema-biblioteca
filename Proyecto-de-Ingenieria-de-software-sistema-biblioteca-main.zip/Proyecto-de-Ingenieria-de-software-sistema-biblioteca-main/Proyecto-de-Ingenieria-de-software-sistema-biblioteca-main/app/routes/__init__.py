# app/routes/__init__.py
from app.routes.tipos_documentos import tipos_bp
from app.routes.main import main
from app.routes.autores import autores_bp  # ✅ AGREGAR ESTA LÍNEA

# Exportar todos los blueprints
__all__ = ['tipos_bp', 'main', 'autores_bp']  # ✅ AGREGAR 'autores_bp'

# Exportar ambos blueprints para que puedan ser importados desde app.routes
__all__ = ['tipos_bp', 'main']