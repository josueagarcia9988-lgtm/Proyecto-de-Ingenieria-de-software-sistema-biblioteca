# app/routes/tipos_documentos.py
from flask import Blueprint, render_template, request, redirect, url_for
from models import obtener_tipos, agregar_tipo, actualizar_tipo, eliminar_tipo

# Crear Blueprint del módulo
tipos_bp = Blueprint('tipos', __name__, template_folder='../templates')

# Listar todos los tipos de documentos
@tipos_bp.route('/tipos')
def listar_tipos():
    tipos = obtener_tipos()
    return render_template('tipos.html', tipos=tipos)

# Crear un nuevo tipo de documento
@tipos_bp.route('/tipos/nuevo', methods=['GET', 'POST'])
def nuevo_tipo():
    if request.method == 'POST':
        nombre = request.form['nombre']
        descripcion = request.form['descripcion']
        activo = request.form.get('activo') == 'on'
        agregar_tipo(nombre, descripcion, activo)
        return redirect(url_for('tipos.listar_tipos'))
    return render_template('nuevo_documento.html')

# Editar un tipo de documento existente
@tipos_bp.route('/tipos/editar/<int:id_tipo>', methods=['GET', 'POST'])
def editar_tipo(id_tipo):
    tipos = obtener_tipos()
    tipo = next((t for t in tipos if t.id_tipo_documento == id_tipo), None)
    if request.method == 'POST':
        nombre = request.form['nombre']
        descripcion = request.form['descripcion']
        activo = request.form.get('activo') == 'on'
        actualizar_tipo(id_tipo, nombre, descripcion, activo)
        return redirect(url_for('tipos.listar_tipos'))
    return render_template('editar_tipo.html', tipo=tipo)

# Eliminar un tipo de documento
@tipos_bp.route('/tipos/eliminar/<int:id_tipo>')
def eliminar(id_tipo):
    eliminar_tipo(id_tipo)
    return redirect(url_for('tipos.listar_tipos'))