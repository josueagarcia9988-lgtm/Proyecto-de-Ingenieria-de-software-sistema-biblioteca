# app/routes/autores.py
from flask import Blueprint, render_template, request, redirect, url_for
from models import obtener_autores, agregar_autor, actualizar_autor, eliminar_autor, obtener_autor_por_id

# Crear Blueprint del módulo
autores_bp = Blueprint('autores', __name__, template_folder='../templates')

# Listar todos los autores
@autores_bp.route('/autores')
def listar_autores():
    autores = obtener_autores()
    return render_template('autores.html', autores=autores)

# Crear un nuevo autor
@autores_bp.route('/autores/nuevo', methods=['GET', 'POST'])
def nuevo_autor():
    if request.method == 'POST':
        nombres = request.form['nombres']
        apellidos = request.form['apellidos']
        nacionalidad = request.form['nacionalidad']
        fecha_nacimiento = request.form['fecha_nacimiento'] or None
        descripcion = request.form['descripcion']
        observaciones = request.form['observaciones']
        agregar_autor(nombres, apellidos, nacionalidad, fecha_nacimiento, descripcion, observaciones)
        return redirect(url_for('autores.listar_autores'))
    return render_template('nuevo_autor.html')

# Editar un autor existente
@autores_bp.route('/autores/editar/<int:id_autor>', methods=['GET', 'POST'])
def editar_autor(id_autor):
    if request.method == 'POST':
        nombres = request.form['nombres']
        apellidos = request.form['apellidos']
        nacionalidad = request.form['nacionalidad']
        fecha_nacimiento = request.form['fecha_nacimiento'] or None
        descripcion = request.form['descripcion']
        observaciones = request.form['observaciones']
        actualizar_autor(id_autor, nombres, apellidos, nacionalidad, fecha_nacimiento, descripcion, observaciones)
        return redirect(url_for('autores.listar_autores'))
    
    autor = obtener_autor_por_id(id_autor)
    return render_template('editar_autor.html', autor=autor)

# Eliminar un autor
@autores_bp.route('/autores/eliminar/<int:id_autor>')
def eliminar(id_autor):
    eliminar_autor(id_autor)
    return redirect(url_for('autores.listar_autores'))